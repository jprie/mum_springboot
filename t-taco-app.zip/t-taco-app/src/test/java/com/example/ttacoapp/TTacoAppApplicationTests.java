package com.example.ttacoapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TTacoAppApplicationTests {

    @Test
    void contextLoads() {
    }

}
