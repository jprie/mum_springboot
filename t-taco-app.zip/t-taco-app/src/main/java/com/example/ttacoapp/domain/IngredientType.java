package com.example.ttacoapp.domain;

public enum IngredientType {
    WRAP, MEAT, VEGGIE, CHEESE, SAUCE
}
