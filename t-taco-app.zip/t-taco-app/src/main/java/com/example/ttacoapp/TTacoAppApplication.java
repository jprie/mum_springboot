package com.example.ttacoapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TTacoAppApplication {

    public static void main(String[] args) {
        SpringApplication.run(TTacoAppApplication.class, args);
    }

}
